// src/main.cpp — JBD BMS Controller (PlatformIO)
// ESP32-C3 Super Mini + GMT020-02 (ST7789 240×320) + JBD BMS
// ─────────────────────────────────────────────────────────────
// ESP32-C3 має ОДИН радіо-модуль (2.4 GHz) для WiFi і BLE.
// Порядок ініціалізації КРИТИЧНИЙ:
//   1. Display  — splash screen поки все завантажується
//   2. WiFi AP  — ПЕРШИМ займає радіо, встановлює AP
//   3. BLE      — ПІСЛЯ WiFi, включається coexistence
//   4. WebServer
// ─────────────────────────────────────────────────────────────
#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>
#include <BLEDevice.h>
#include <BLEClient.h>
#include <BLEScan.h>
#include <BLERemoteCharacteristic.h>
#include <esp_wifi.h>          // esp_wifi_set_ps()

// ─── Порядок підключення заголовків ВАЖЛИВИЙ ─────────────────
#include "GLOBAL_STATE.h"
#include "wifi_manager.h"      // WiFi — підключати ПЕРЕД bms.h
#include "bms.h"
#include "display.h"           // LovyanGFX — до web_server.h (setDisplayPower!)
#include "web_server.h"        // includes html_page.h (PROGMEM)
#include "api_client.h"

// ─── Визначення глобальних змінних ───────────────────────────
// (оголошені extern у GLOBAL_STATE.h, визначаються ТІЛЬКИ тут)

// BLE
BLEClient*               pClient           = nullptr;
BLERemoteCharacteristic* pTxCharacteristic = nullptr;
BLERemoteCharacteristic* pRxCharacteristic = nullptr;
uint8_t   bmsResponse[512]  = {};
size_t    bmsResponseLength = 0;
bool      newDataReceived   = false;
bool      bmsConnected      = false;
bool      isScanning        = false;
int       bmsCount          = 0;
String    availableBMS[20];
String    BMS_MAC           = "";
String    BMS_NAME          = "";

// WiFi
bool          wifiConnected        = false;
bool          wifiConfigured       = false;
String        wifiSSID             = "";
String        wifiPassword         = "";
IPAddress     localIP;
unsigned long wifiConnectStartTime = 0;

// Config
String    apiServer  = "";
String    deviceId   = "ESP32-BMS-01";

// Display
bool      displayDetected = false;
bool      displayActive   = false;

// System
bool      shouldRestart   = false;

// BMS data
BMSData   bmsData = {};

// ─── Constants ───────────────────────────────────────────────
const unsigned long BMS_UPDATE_MS    = 3000;
const unsigned long BMS_RECONNECT_MS = 20000;
const uint8_t       LED_PIN          = 8;
const uint8_t       BOOT_BTN_PIN     = 9;

// ─── Setup ───────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("\n[Main] JBD BMS Controller — ESP32-C3 Super Mini");

  pinMode(LED_PIN,       OUTPUT);
  pinMode(BOOT_BTN_PIN,  INPUT_PULLUP);
  digitalWrite(LED_PIN,  LOW);

  // 1. Display — splash поки решта завантажується
  initDisplay();

  // 2. WiFi AP — ПЕРШИМ, до BLE
  // ESP32-C3: один радіо. WiFi повинен захопити радіо першим.
  initWiFiManager();

  // 3. BLE — ПІСЛЯ WiFi, coexistence автоматично
  // BLEDevice::init() активує coexistence driver.
  initBMS();

  // 4. Web Server
  initWebServer();

  Serial.println("[Main] Init done");
  Serial.printf("[Main] AP: http://%s  (SSID: %s)\n",
    WiFi.softAPIP().toString().c_str(), DEFAULT_AP_PREFIX);

  // Автопідключення до збереженого BMS
  if (BMS_MAC.length() > 0) {
    Serial.printf("[Main] Auto-connect BMS: %s\n", BMS_MAC.c_str());
    connectToBMS(BMS_MAC, BMS_NAME);
  }

  digitalWrite(LED_PIN, HIGH);
}

// ─── Loop ────────────────────────────────────────────────────
static unsigned long lastBMSUpdate    = 0;
static unsigned long lastBMSReconnect = 0;
static unsigned long lastLedBlink     = 0;
static uint8_t       ledState         = HIGH;
static bool          lastBtn          = HIGH;
static uint32_t      btnAt            = 0;

void loop() {
  // Serial CLI
  handleSerialCommands();

  // WiFi STA check
  handleWiFiManager();

  // HTTP server
  server.handleClient();

  // BMS data update
  if (bmsConnected) {
    if (millis() - lastBMSUpdate > BMS_UPDATE_MS) {
      lastBMSUpdate = millis();
      if (!updateBMSData()) {
        Serial.println("[Main] BMS update failed");
        bmsConnected = false;
      }
    }
  } else if (BMS_MAC.length() > 0) {
    if (millis() - lastBMSReconnect > BMS_RECONNECT_MS) {
      lastBMSReconnect = millis();
      connectToBMS(BMS_MAC, BMS_NAME);
    }
  }

  // API push to Replit
  handleAPIData();

  // Display render (10 fps throttled inside)
  handleDisplay();

  // BOOT button: short = next page, long (>1s) = toggle display
  bool curBtn = digitalRead(BOOT_BTN_PIN);
  if (lastBtn == HIGH && curBtn == LOW)  btnAt = millis();
  if (lastBtn == LOW  && curBtn == HIGH) {
    if (millis() - btnAt < 1000) nextDisplayPage();
    else                         setDisplayPower(!displayActive);
  }
  lastBtn = curBtn;

  // LED heartbeat: fast=BMS OK, slow=no BMS
  uint32_t blinkMs = bmsConnected ? 500 : 2000;
  if (millis() - lastLedBlink > blinkMs) {
    lastLedBlink = millis();
    ledState = !ledState;
    digitalWrite(LED_PIN, ledState);
  }

  // Restart after /save
  if (shouldRestart) {
    delay(1000);
    ESP.restart();
  }

  yield();
}
