// GLOBAL_STATE.h — Спільний стан проекту JBD BMS Controller
// ESP32-C3 Super Mini + GMT020-02 (ST7789 240×320)
// ─────────────────────────────────────────────────────────
// ПІДКЛЮЧЕННЯ ДИСПЛЕЮ GMT020-02:
//  GMT020-02 Pin  │ ESP32-C3 GPIO │ Примітка
//  ───────────────┼───────────────┼──────────────────────
//  Pin 1  LED+    │ GPIO 11       │ Підсвітка (через 33Ω)
//  Pin 2  LED-    │ GND           │
//  Pin 3  IM2     │ 3V3           │ SPI режим (IM2=H)
//  Pin 4  IM1     │ 3V3           │ SPI режим (IM1=H)
//  Pin 5  IM0     │ GND           │ SPI режим (IM0=L)
//  Pin 6  VCC     │ 3V3           │ 2.8–3.3V
//  Pin 16 WR/DC   │ GPIO 2        │ Data/Command
//  Pin 17 RS/SCL  │ GPIO 4        │ SPI Clock (FSPI)
//  Pin 18 CS      │ GPIO 7        │ Chip Select
//  Pin 20 RESET   │ GPIO 3        │ Reset
//  Pin 21 SDA     │ GPIO 6        │ SPI MOSI (FSPI)
//  Pin 22 GND     │ GND           │
//  (pins 7-15, 19 не підключені в SPI режимі)
//
// BOOT кнопка GPIO9 → перемикання сторінок дисплею
// Вбудований LED   → GPIO8
// ─────────────────────────────────────────────────────────

#pragma once

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEClient.h>
#include <BLERemoteCharacteristic.h>
#include <WiFi.h>

// ─── JBD BMS BLE UUIDs ────────────────────────────────
#define SERVICE_UUID  "0000ff00-0000-1000-8000-00805f9b34fb"
#define CHAR_TX_UUID  "0000ff01-0000-1000-8000-00805f9b34fb"  // BMS→ESP Notify
#define CHAR_RX_UUID  "0000ff02-0000-1000-8000-00805f9b34fb"  // ESP→BMS Write

// ─── Default AP ───────────────────────────────────────
#define DEFAULT_AP_PREFIX    "JBD-BMS-ESP32"
#define DEFAULT_AP_PASSWORD  "bms12345"

// ─── BMS Data Structure ───────────────────────────────
struct BMSData {
  // Basic info (register 0x03)
  float    totalVoltage;       // В — bmsResponse[4..5] / 100
  float    current;            // А — bmsResponse[6..7] / 100, signed
  float    capacityRemaining;  // Аг — bmsResponse[8..9] / 100
  float    capacityTotal;      // Аг — bmsResponse[10..11] / 100
  uint16_t cycleCount;         // шт — bmsResponse[12..13]
  String   productionDate;     // "20YY/MM/DD"
  uint16_t balanceStatus;      // bitmask клітини 1-16 (bmsResponse[17..18])
  uint16_t balanceStatusHigh;  // bitmask клітини 17-32 (bmsResponse[19..20])
  uint16_t protectionStatus;   // bit0-bit12 (bmsResponse[21..22])
  uint8_t  softwareVersion;    // bmsResponse[23]
  uint8_t  fetStatus;          // bmsResponse[24]: bit0=CHG, bit1=DSG
  uint8_t  cellCount;          // bmsResponse[25]
  uint8_t  tempSensorCount;    // bmsResponse[26]
  float    temperatures[6];    // °C — (raw-2731)/10
  uint8_t  soc;                // % — розраховується: capRem/capTot*100

  // Cell voltages (register 0x04)
  float    cellVoltages[24];   // В — raw/1000, до 24 клітин
};

// ─── Extern declarations (definitions у BMS_Controller.ino) ──

// BLE
extern BLEClient*               pClient;
extern BLERemoteCharacteristic* pTxCharacteristic;
extern BLERemoteCharacteristic* pRxCharacteristic;
extern uint8_t   bmsResponse[512];
extern size_t    bmsResponseLength;
extern bool      newDataReceived;
extern bool      bmsConnected;
extern bool      isScanning;
extern int       bmsCount;
extern String    availableBMS[20];
extern String    BMS_MAC;
extern String    BMS_NAME;

// WiFi
extern bool          wifiConnected;
extern bool          wifiConfigured;
extern String        wifiSSID;
extern String        wifiPassword;
extern IPAddress     localIP;
extern unsigned long wifiConnectStartTime;

// Config (Preferences "app-config")
extern String    apiServer;   // URL для Replit
extern String    deviceId;    // ID пристрою

// Display
extern bool      displayDetected;
extern bool      displayActive;

// System
extern bool      shouldRestart;  // true → ESP.restart() у loop()

// BMS data
extern BMSData   bmsData;
