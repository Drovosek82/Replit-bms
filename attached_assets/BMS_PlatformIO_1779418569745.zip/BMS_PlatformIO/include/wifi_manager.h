// wifi_manager.h — WiFi AP + STA + Preferences
// ESP32-C3: ОДИН радіо-модуль для WiFi і BLE.
// Ключові фікси для стабільного AP з BLE:
//   - WiFi.setSleep(false)       → вимкнути WiFi-сон
//   - esp_wifi_set_ps(WIFI_PS_NONE) → без енергозбереження
//   - WiFi ініціалізується ДО BLE (у BMS_Controller.ino)
// ─────────────────────────────────────────────────────────
#pragma once

#include <Arduino.h>
#include <WiFi.h>
#include <Preferences.h>
#include <esp_wifi.h>
#include "GLOBAL_STATE.h"

// ─── Forward declarations ────────────────────────────────
inline void scanWiFiNetworks(String nets[], int& count, int maxN);
inline bool saveWiFiConfig(const String& ssid, const String& pass);
inline bool saveAppConfig(const String& server, const String& id);

// ─── initWiFiManager ─────────────────────────────────────
inline void initWiFiManager() {
  // Зчитати збережену конфігурацію
  {
    Preferences p;
    p.begin("wifi-cfg", true);
    wifiSSID     = p.getString("ssid", "");
    wifiPassword = p.getString("pass", "");
    p.end();
    wifiConfigured = (wifiSSID.length() > 0);
  }
  {
    Preferences p;
    p.begin("app-cfg", true);
    apiServer = p.getString("api",    "");
    deviceId  = p.getString("dev",    "ESP32-BMS-01");
    p.end();
  }

  // ── Режим AP (завжди активний) ─────────────────────────
  // Якщо є STA-конфіг — одразу AP+STA, інакше тільки AP.
  WiFi.mode(wifiConfigured ? WIFI_AP_STA : WIFI_AP);

  // ┌─────────────────────────────────────────────────────┐
  // │ КРИТИЧНО для ESP32-C3 (один радіо-модуль):          │
  // │ Вимкнути WiFi power-save ДО BLE init.               │
  // │ Без цього AP зникає як тільки BLE стартує.          │
  // └─────────────────────────────────────────────────────┘
  WiFi.setSleep(false);           // Arduino wrapper
  esp_wifi_set_ps(WIFI_PS_NONE);  // IDF рівень (дублювання для надійності)

  // Старт AP: канал 6, прихований=0, макс клієнтів=4
  bool ok = WiFi.softAP(DEFAULT_AP_PREFIX, DEFAULT_AP_PASSWORD, 6, 0, 4);
  if (ok) {
    Serial.printf("[WiFi] AP OK  SSID: %s  IP: %s\n",
      DEFAULT_AP_PREFIX, WiFi.softAPIP().toString().c_str());
  } else {
    Serial.println("[WiFi] AP FAILED");
  }

  // Повторно вимкнути power-save після softAP
  // (деякі версії SDK скидають його після mode change)
  esp_wifi_set_ps(WIFI_PS_NONE);

  // Старт STA якщо є збережена мережа
  if (wifiConfigured) {
    WiFi.begin(wifiSSID.c_str(), wifiPassword.c_str());
    wifiConnectStartTime = millis();
    Serial.printf("[WiFi] STA connecting: %s\n", wifiSSID.c_str());
  }
}

// ─── handleWiFiManager — викликати в loop() ──────────────
inline void handleWiFiManager() {
  static unsigned long lastCheck = 0;
  if (millis() - lastCheck < 3000) return;
  lastCheck = millis();

  if (wifiConfigured) {
    if (WiFi.status() == WL_CONNECTED) {
      if (!wifiConnected) {
        wifiConnected = true;
        localIP = WiFi.localIP();
        Serial.printf("[WiFi] STA OK  IP: %s\n", localIP.toString().c_str());
        // Після підключення STA — знову вимкнути power-save
        esp_wifi_set_ps(WIFI_PS_NONE);
      }
    } else {
      if (wifiConnected) {
        wifiConnected = false;
        Serial.println("[WiFi] STA disconnected");
      }
      // Повторна спроба кожні 30 с
      if (millis() - wifiConnectStartTime > 30000) {
        wifiConnectStartTime = millis();
        WiFi.disconnect();
        WiFi.begin(wifiSSID.c_str(), wifiPassword.c_str());
        Serial.println("[WiFi] STA retry");
      }
    }
  }
}

// ─── scanWiFiNetworks ────────────────────────────────────
inline void scanWiFiNetworks(String nets[], int& count, int maxN) {
  count = 0;
  // Сканування не конфліктує з AP у режимі AP+STA
  int n = WiFi.scanNetworks(false, false); // blocking, no hidden
  for (int i = 0; i < n && count < maxN; i++) {
    // Формат: "SSID|RSSI|isSecure"
    nets[count++] = WiFi.SSID(i) + "|" +
                    String(WiFi.RSSI(i)) + "|" +
                    String(WiFi.encryptionType(i) != WIFI_AUTH_OPEN ? "1" : "0");
    yield();
  }
  WiFi.scanDelete();
  // Після сканування знову вимкнути power-save
  esp_wifi_set_ps(WIFI_PS_NONE);
  Serial.printf("[WiFi] Scan: %d networks\n", count);
}

// ─── saveWiFiConfig ──────────────────────────────────────
inline bool saveWiFiConfig(const String& ssid, const String& pass) {
  Preferences p;
  p.begin("wifi-cfg", false);
  p.putString("ssid", ssid);
  p.putString("pass", pass);
  p.end();
  wifiSSID       = ssid;
  wifiPassword   = pass;
  wifiConfigured = true;
  Serial.printf("[WiFi] Config saved: %s\n", ssid.c_str());
  return true;
}

// ─── saveAppConfig ───────────────────────────────────────
inline bool saveAppConfig(const String& srv, const String& id) {
  Preferences p;
  p.begin("app-cfg", false);
  p.putString("api", srv);
  p.putString("dev", id);
  p.end();
  apiServer = srv;
  deviceId  = id;
  Serial.printf("[WiFi] App config saved: %s / %s\n", srv.c_str(), id.c_str());
  return true;
}

// ─── handleSerialCommands ────────────────────────────────
inline void handleSerialCommands() {
  if (!Serial.available()) return;
  String cmd = Serial.readStringUntil('\n');
  cmd.trim();
  if (cmd.length() == 0) return;

  Serial.printf("[CLI] > %s\n", cmd.c_str());

  if (cmd == "help") {
    Serial.println("Commands: status | scan | restart | wifi <ssid> <pass> | api <url>");
  } else if (cmd == "status") {
    Serial.printf("  AP:  %s (%s)\n", DEFAULT_AP_PREFIX, WiFi.softAPIP().toString().c_str());
    Serial.printf("  STA: %s  IP: %s\n",
      wifiConnected ? "OK" : "disconnected",
      wifiConnected ? localIP.toString().c_str() : "n/a");
    Serial.printf("  BMS: %s  %s\n",
      bmsConnected ? "connected" : "disconnected", BMS_MAC.c_str());
    Serial.printf("  API: %s\n", apiServer.length() ? apiServer.c_str() : "(not set)");
  } else if (cmd == "scan") {
    String nets[20]; int cnt = 0;
    scanWiFiNetworks(nets, cnt, 20);
    for (int i = 0; i < cnt; i++) Serial.printf("  %d: %s\n", i+1, nets[i].c_str());
  } else if (cmd == "restart") {
    shouldRestart = true;
  } else if (cmd.startsWith("wifi ")) {
    int s = cmd.indexOf(' ', 5);
    if (s > 0) {
      saveWiFiConfig(cmd.substring(5, s), cmd.substring(s+1));
      Serial.println("  Saved. Restarting...");
      shouldRestart = true;
    }
  } else if (cmd.startsWith("api ")) {
    saveAppConfig(cmd.substring(4), deviceId);
    Serial.println("  API saved");
  } else {
    Serial.println("  Unknown. Type 'help'");
  }
}
