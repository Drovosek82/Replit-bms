// display.h — Modern animated ST7789 240×320 display for JBD BMS
// LovyanGFX | Arc gauge | Sprite | Smooth lerp | 10 fps
//
// Сторінки:
//   0 — Dashboard : кругова дуга SOC, великі метрики, анімовані cell bars
//   1 — Cell V    : горизонтальні анімовані бари всіх клітин
//   2 — Status    : WiFi / BMS / захист / конфіг
//
// Анімації:
//   • Плавний lerp для всіх числових значень (SOC, V, A, W, T, клітини)
//   • Дуга SOC плавно наростає/спадає
//   • Grow-in ефект при вході на сторінку
//   • Блимання статусних індикаторів (OK=зелений, fault=червоний)
//   • Pulse гало навколо великих чисел при зміні значення
//   • Page-wipe перехід між сторінками
//
// Sprite 240×130 (60 KB) — SOC gauge без мерехтіння
// Frame rate: 100 мс (10 fps) при оновленні даних BMS кожні 3 с
// ─────────────────────────────────────────────────────────
#pragma once
#include <Arduino.h>

#include "lgfx_config.h"
#include <WiFi.h>
#include "GLOBAL_STATE.h"

// ════════════════════════════════════════════════════════
//  Палітра RGB565
// ════════════════════════════════════════════════════════
#define C_BG      0x0841   // #0A0C20  фон
#define C_SUR     0x0C63   // #0C1820  поверхня
#define C_SUR2    0x1486   // #142830  підвищена
#define C_BRD     0x1D4A   // border
#define C_ACCENT  0x07BF   // #00D0FF  ціан
#define C_GREEN   0x07E0   // #00FF00  зелений
#define C_GREEN2  0x2D65   // #2ACC28  м'який зелений
#define C_YELLOW  0xFD20   // #FFA800  amber
#define C_RED     0xF945   // #FF2828  червоний
#define C_BLUE    0x03BF   // #0070FF  синій/холодний
#define C_WHITE   0xFFFF
#define C_LGRAY   0xAD55
#define C_GRAY    0x6B4D
#define C_DGRAY   0x2D4A
#define C_BLACK   0x0000

// ════════════════════════════════════════════════════════
//  Layout  Portrait 240×320
// ════════════════════════════════════════════════════════
#define W     240
#define H     320
#define HDR_H  28
#define FTR_H  24
#define CTX_Y  HDR_H
#define CTX_H  (H - HDR_H - FTR_H)   // 268 px

// Gauge параметри
#define GCX     120        // gauge center X
#define GCY     (CTX_Y+96) // gauge center Y (абсолютна)
#define G_RIN    40        // inner radius
#define G_ROUT   56        // outer radius
#define G_RGLO   60        // glow radius
#define G_START  225.0f    // deg (8 o'clock)
#define G_SPAN   270.0f    // total arc degrees

// ════════════════════════════════════════════════════════
//  LovyanGFX instances
// ════════════════════════════════════════════════════════
static LGFX        _tft;
static LGFX_Sprite _spr(&_tft);   // 240×130 for SOC gauge section (60 KB)

// ════════════════════════════════════════════════════════
//  Smooth lerp helper
// ════════════════════════════════════════════════════════
struct LerpF {
  float c = 0, t = 0;
  void  snap(float v)         { c = t = v; }
  void  set(float v)          { t = v; }
  float step(float s = 0.10f) { c += (t - c) * s; return c; }
  float get() const           { return c; }
  bool  dirty(float eps=0.01f)const { return fabsf(t - c) > eps; }
};

// ════════════════════════════════════════════════════════
//  Animation state
// ════════════════════════════════════════════════════════
static struct {
  LerpF soc, volt, curr, pwr;
  LerpF cells[24];
  LerpF temps[3];
  LerpF arcAngle;          // displayed arc fill degrees
  float pulseVolt = 0;     // 0..1 pulse intensity on voltage
  float pulseCurr = 0;
  uint8_t enterStep = 20;  // 0=page just changed, 20=fully shown
  uint32_t lastFrameMs = 0;
} _A;

// ════════════════════════════════════════════════════════
//  Display state
// ════════════════════════════════════════════════════════
static uint8_t  _pg       = 0;
static uint8_t  _PG_CNT   = 3;
static uint32_t _pgTimer  = 0;
static uint32_t _PG_MS    = 8000;
static uint32_t _drawMs   = 0;
static uint32_t _DRAW_MS  = 100;   // 10 fps
static uint8_t  _brt      = 220;
static bool     _inited   = false;
static bool     _spriteReady = false;  // ← ліниве виділення після BLE init
static bool     _blState  = false;
static uint32_t _blTimer  = 0;

static const char* _pgNames[3] = {"Dashboard","Cell V","Status"};

// ════════════════════════════════════════════════════════
//  Helpers
// ════════════════════════════════════════════════════════
static inline bool _blink(uint16_t ms = 500) {
  return (millis() % (ms*2)) < ms;
}
static inline uint16_t _socClr(float s) {
  return s < 15 ? C_RED : s < 30 ? C_YELLOW : C_GREEN2;
}
static inline uint16_t _tempClr(float t) {
  return t > 50 ? C_RED : t > 40 ? C_YELLOW : t < 5 ? C_BLUE : C_GREEN2;
}
// Blend two RGB565 colours (0..255 alpha)
static inline uint16_t _blend(uint16_t a, uint16_t b, uint8_t alpha) {
  uint8_t ra = (a >> 11) & 0x1F, ga = (a >> 5) & 0x3F, ba = a & 0x1F;
  uint8_t rb = (b >> 11) & 0x1F, gb = (b >> 5) & 0x3F, bb = b & 0x1F;
  uint8_t ro = ra + ((int)(rb-ra)*alpha >> 8);
  uint8_t go = ga + ((int)(gb-ga)*alpha >> 8);
  uint8_t bo = ba + ((int)(bb-ba)*alpha >> 8);
  return (ro<<11)|(go<<5)|bo;
}
static inline float _clamp(float v,float lo,float hi){ return v<lo?lo:v>hi?hi:v; }

// ════════════════════════════════════════════════════════
//  Step all lerps (кожен кадр)
// ════════════════════════════════════════════════════════
static void _stepAnim() {
  float spd = 0.12f;
  _A.soc.step(spd);
  _A.volt.step(spd);
  _A.curr.step(spd);
  _A.pwr.step(spd);
  _A.arcAngle.step(0.08f);       // arc дещо повільніший
  for (uint8_t i = 0; i < 3;  i++) _A.temps[i].step(spd);
  for (uint8_t i = 0; i < 24; i++) _A.cells[i].step(0.15f);

  // Pulse decay
  _A.pulseVolt *= 0.85f;
  _A.pulseCurr *= 0.85f;

  // Enter animation
  if (_A.enterStep < 20) _A.enterStep++;
}

// ════════════════════════════════════════════════════════
//  Update lerp targets from bmsData
// ════════════════════════════════════════════════════════
static void _updateTargets() {
  float prevV = _A.volt.t, prevI = _A.curr.t;

  _A.soc.set(bmsData.soc);
  _A.volt.set(bmsData.totalVoltage);
  _A.curr.set(bmsData.current);
  _A.pwr.set(bmsData.totalVoltage * bmsData.current);
  _A.arcAngle.set(G_SPAN * _clamp(bmsData.soc / 100.0f, 0, 1));

  for (uint8_t i = 0; i < bmsData.tempSensorCount && i < 3; i++)
    _A.temps[i].set(bmsData.temperatures[i]);
  for (uint8_t i = 0; i < bmsData.cellCount && i < 24; i++)
    _A.cells[i].set(bmsData.cellVoltages[i]);

  // Trigger pulse if value changed significantly
  if (fabsf(_A.volt.t - prevV) > 0.05f) _A.pulseVolt = 1.0f;
  if (fabsf(_A.curr.t - prevI) > 0.1f)  _A.pulseCurr = 1.0f;
}

// ════════════════════════════════════════════════════════
//  Header  (28 px)
// ════════════════════════════════════════════════════════
static void _drawHdr(const char* title) {
  _tft.fillRect(0, 0, W, HDR_H, C_SUR);
  _tft.drawFastHLine(0, HDR_H-1, W, C_BRD);

  _tft.setTextColor(C_ACCENT, C_SUR);
  _tft.setTextDatum(ML_DATUM); _tft.setTextFont(2);
  _tft.drawString(title, 8, HDR_H/2+1);

  // WiFi dot
  bool wOk = wifiConnected;
  _tft.fillCircle(W-40, HDR_H/2, 4, wOk ? C_GREEN2 : (_blink(800)?C_RED:C_DGRAY));
  _tft.drawCircle(W-40, HDR_H/2, 5, wOk ? C_GREEN2 : C_DGRAY);
  _tft.setTextFont(1); _tft.setTextColor(C_GRAY, C_SUR);
  _tft.drawString("W", W-33, HDR_H/2+1);

  // BMS dot
  _tft.fillCircle(W-20, HDR_H/2, 4, bmsConnected ? C_GREEN2 : (_blink(800)?C_RED:C_DGRAY));
  _tft.drawCircle(W-20, HDR_H/2, 5, bmsConnected ? C_GREEN2 : C_DGRAY);
  _tft.drawString("B", W-13, HDR_H/2+1);
}

// ════════════════════════════════════════════════════════
//  Footer  (24 px)
// ════════════════════════════════════════════════════════
static void _drawFtr() {
  int16_t fy = H - FTR_H;
  _tft.fillRect(0, fy, W, FTR_H, C_SUR);
  _tft.drawFastHLine(0, fy, W, C_BRD);

  // Dots
  int16_t dx = W/2 - (_PG_CNT*14)/2;
  for (uint8_t i = 0; i < _PG_CNT; i++) {
    bool act = (i == _pg);
    _tft.fillCircle(dx+i*14, fy+FTR_H/2, act?5:3, act?C_ACCENT:C_DGRAY);
    if (act) _tft.drawCircle(dx+i*14, fy+FTR_H/2, 7, _blend(C_ACCENT,C_BG,60));
  }

  // Page name
  _tft.setTextFont(1); _tft.setTextColor(C_GRAY, C_SUR);
  _tft.setTextDatum(MR_DATUM);
  _tft.drawString(_pgNames[_pg], W-6, fy+FTR_H/2+1);

  // Countdown bar
  float rem = 1.0f - _clamp((float)(millis()-_pgTimer)/_PG_MS, 0,1);
  _tft.fillRect(4, fy+FTR_H/2-2, 34, 4, C_BRD);
  int16_t bw = (int16_t)(34*rem);
  if (bw>0) _tft.fillRect(4, fy+FTR_H/2-2, bw, 4, _blend(C_ACCENT,C_BG,80));
}

// ════════════════════════════════════════════════════════
//  PAGE 0 — DASHBOARD
// ════════════════════════════════════════════════════════
// Layout:
//  28..157  SOC gauge  (sprite, 130 px)
//  158..207 Current + Power (50 px)
//  208..237 Temp + FET (30 px)
//  238..293 Cell bars  (56 px)

// ── SOC Arc Gauge (sprite-backed) ───────────────────────
static void _drawGauge() {
  const int16_t SY = CTX_Y;
  const int16_t SH = 130;
  const int16_t cx = GCX - 0;
  const int16_t cy = GCY - SY;

  // ── Ліниве виділення спрайту (після BLE init, коли є RAM) ──
  if (!_spriteReady) {
    _spr.setColorDepth(16);
    _spriteReady = _spr.createSprite(W, 130);
    if (_spriteReady) {
      Serial.println("[Display] Sprite 240x130 allocated OK");
    } else {
      Serial.println("[Display] Sprite alloc failed — direct draw");
    }
  }

  // ── Якщо спрайт є — малюємо в нього, потім pushSprite ──
  // ── Якщо немає — малюємо прямо на _tft (з невеликим мерехтінням) ──
  LGFX_Sprite* G = _spriteReady ? &_spr : nullptr;

  auto gFill    = [&](uint16_t c)                         { if(G) G->fillSprite(c);          else _tft.fillRect(0,SY,W,SH,c); };
  auto gFillArc = [&](int cx2,int cy2,int r,int ir,float s,float e,uint16_t c) {
    if(G) G->fillArc(cx2,cy2,r,ir,s,e,c); else _tft.fillArc(cx2,cy2+SY,r,ir,s,e,c); };
  auto gCircle  = [&](int x,int y,int r,uint16_t c)       { if(G) G->fillCircle(x,y,r,c);   else _tft.fillCircle(x,y+SY,r,c); };
  auto gText    = [&](LGFX_Sprite* /*unused*/,auto&... a)  {};  // unused alias
  auto gStr     = [&](auto* obj, const char* s, int x, int y) {
    if(G){ obj->setTextDatum(MC_DATUM); obj->drawString(s,x,y); }
    else { _tft.setTextDatum(MC_DATUM); _tft.drawString(s,x,y+SY); }
  };

  gFill(C_BG);

  float soc    = _A.soc.get();
  float volt   = _A.volt.get();
  float angle  = _A.arcAngle.get();
  uint16_t sc  = _socClr(soc);

  // Вибір цільового об'єкту: спрайт або прямо на _tft
  LovyanGFX* tgt = _spriteReady ? (LovyanGFX*)&_spr : (LovyanGFX*)&_tft;
  int16_t yOff   = _spriteReady ? 0 : SY;  // зміщення Y для прямого малювання

  if (_spriteReady) _spr.fillSprite(C_BG);
  else _tft.fillRect(0, SY, W, SH, C_BG);

  // ── Glow ring ──────────────────────────────────────────
  uint16_t gcDim = _blend(sc, C_BG, 30);
  tgt->fillArc(cx, cy+yOff, G_ROUT+2, G_RGLO, G_START, G_START+G_SPAN, C_BRD);
  if (angle > 1.0f)
    tgt->fillArc(cx, cy+yOff, G_ROUT+2, G_RGLO, G_START, G_START+angle, gcDim);

  // ── Background arc ─────────────────────────────────────
  tgt->fillArc(cx, cy+yOff, G_RIN, G_ROUT, G_START, G_START+G_SPAN, C_SUR2);

  // ── Fill arc (SOC level) ────────────────────────────────
  if (angle > 0.5f) {
    tgt->fillArc(cx, cy+yOff, G_RIN, G_ROUT, G_START, G_START+angle, sc);
    if (angle > 8.0f)
      tgt->fillArc(cx, cy+yOff, G_RIN+3, G_ROUT-3,
                   G_START+angle-7, G_START+angle, _blend(sc, C_WHITE, 90));
  }

  // ── Tick marks ─────────────────────────────────────────
  for (int t = 0; t <= 100; t += 25) {
    float drad = (G_START + G_SPAN * t / 100.0f) * 3.14159f / 180.0f;
    float tx = cx + (G_ROUT+7) * sinf(drad);
    float ty = cy + yOff - (G_ROUT+7) * cosf(drad);
    tgt->fillCircle((int)tx, (int)ty, 1, t==0||t==100 ? C_LGRAY : C_DGRAY);
  }

  // ── Center circle ──────────────────────────────────────
  tgt->fillCircle(cx, cy+yOff, G_RIN-2, C_BG);

  // ── SOC number ─────────────────────────────────────────
  char sbuf[8];
  snprintf(sbuf, sizeof(sbuf), "%d", (int)(soc + 0.5f));
  tgt->setTextDatum(MC_DATUM);
  tgt->setTextFont(7);
  tgt->setTextColor(sc, C_BG);
  tgt->drawString(sbuf, cx, cy+yOff-6);

  tgt->setTextFont(2); tgt->setTextColor(C_GRAY, C_BG);
  tgt->drawString("%", cx+22, cy+yOff+14);

  // ── Voltage ────────────────────────────────────────────
  char vbuf[10];
  snprintf(vbuf, sizeof(vbuf), "%.2fV", volt);
  tgt->setTextFont(2);
  uint16_t vc = _A.pulseVolt > 0.05f
    ? _blend(C_ACCENT, C_WHITE, (uint8_t)(_A.pulseVolt*200))
    : C_ACCENT;
  tgt->setTextColor(vc, C_BG);
  tgt->setTextDatum(MC_DATUM);
  tgt->drawString(vbuf, cx, cy+yOff+32);

  // ── Capacity Ah ────────────────────────────────────────
  char cbuf[18];
  snprintf(cbuf, sizeof(cbuf), "%.1f / %.0f Ah",
           bmsData.capacityRemaining, bmsData.capacityTotal);
  tgt->setTextFont(1); tgt->setTextColor(C_DGRAY, C_BG);
  tgt->drawString(cbuf, cx, cy+yOff+46);

  // ── Balance indicator ──────────────────────────────────
  if (bmsData.balanceStatus || bmsData.balanceStatusHigh) {
    uint16_t bc = _blink(400) ? C_YELLOW : C_DGRAY;
    tgt->setTextFont(1); tgt->setTextColor(bc, C_BG);
    tgt->setTextDatum(MC_DATUM);
    tgt->drawString("~ BAL", cx, cy+yOff-32);
  }

  if (_spriteReady) _spr.pushSprite(0, SY);
}

// ── Current + Power row ─────────────────────────────────
static void _drawMetrics() {
  const int16_t y0 = 158;
  _tft.fillRect(0, y0, W, 50, C_BG);

  float curr  = _A.curr.get();
  float pwr   = _A.pwr.get();
  bool  isChg = (curr < -0.05f);
  char  buf[16];

  // ── Current (left half) ──────────────────────────────
  uint16_t ic = _A.pulseCurr > 0.05f
    ? _blend(C_YELLOW, C_WHITE, (uint8_t)(_A.pulseCurr*200))
    : C_YELLOW;
  snprintf(buf, sizeof(buf), "%.2f", fabsf(curr));
  _tft.setTextFont(6);           // 48px digits
  _tft.setTextColor(ic, C_BG);
  _tft.setTextDatum(MR_DATUM);
  _tft.drawString(buf, 112, y0+22);

  _tft.setTextFont(1); _tft.setTextColor(C_DGRAY, C_BG);
  _tft.setTextDatum(ML_DATUM);
  _tft.drawString("A", 114, y0+14);
  _tft.setTextColor(isChg ? C_GREEN2 : C_YELLOW, C_BG);
  _tft.drawString(isChg ? "CHG" : "DSG", 114, y0+28);

  // Divider
  _tft.drawFastVLine(W/2, y0+6, 38, C_BRD);

  // ── Power (right half) ──────────────────────────────
  snprintf(buf, sizeof(buf), "%.0f", fabsf(pwr));
  _tft.setTextFont(6); _tft.setTextColor(C_GREEN2, C_BG);
  _tft.setTextDatum(MR_DATUM);
  _tft.drawString(buf, W-18, y0+22);

  _tft.setTextFont(1); _tft.setTextColor(C_DGRAY, C_BG);
  _tft.setTextDatum(ML_DATUM);
  _tft.drawString("W", W-15, y0+14);
  _tft.drawString("PWR", W-15, y0+28);

  _tft.drawFastHLine(0, y0+49, W, C_BRD);
}

// ── Temperature + FET row ───────────────────────────────
static void _drawTempFET() {
  const int16_t y0 = 208;
  _tft.fillRect(0, y0, W, 30, C_BG);

  char buf[12];
  uint8_t tc = bmsData.tempSensorCount;

  // Temps (left ⅔)
  int16_t tCW = (tc > 0) ? ((W*2/3) / tc) : W*2/3;
  for (uint8_t i = 0; i < tc && i < 3; i++) {
    float t = _A.temps[i].get();
    snprintf(buf, sizeof(buf), "%.1f\xB0", t);
    _tft.setTextFont(2); _tft.setTextDatum(MC_DATUM);
    _tft.setTextColor(_tempClr(t), C_BG);
    _tft.drawString(buf, i*tCW + tCW/2, y0+12);
    _tft.setTextFont(1); _tft.setTextColor(C_DGRAY, C_BG);
    char tn[4]; snprintf(tn, sizeof(tn), "T%d", i+1);
    _tft.drawString(tn, i*tCW + tCW/2, y0+24);
  }

  // FET (right ⅓)
  _tft.drawFastVLine(W*2/3, y0+4, 22, C_BRD);
  bool chg = (bmsData.fetStatus>>0)&1, dsg = (bmsData.fetStatus>>1)&1;
  int16_t fx = W*2/3 + 6;
  _tft.setTextFont(1); _tft.setTextDatum(ML_DATUM);

  _tft.setTextColor(C_DGRAY, C_BG); _tft.drawString("CHG", fx, y0+10);
  _tft.fillCircle(fx+22, y0+10, 4, chg ? C_GREEN2 : C_RED);
  if (!chg && _blink(300)) _tft.fillCircle(fx+22, y0+10, 4, C_BG);

  _tft.setTextColor(C_DGRAY, C_BG); _tft.drawString("DSG", fx, y0+22);
  _tft.fillCircle(fx+22, y0+22, 4, dsg ? C_GREEN2 : C_RED);
  if (!dsg && _blink(300)) _tft.fillCircle(fx+22, y0+22, 4, C_BG);

  _tft.drawFastHLine(0, y0+29, W, C_BRD);
}

// ── Cell mini bars overview ──────────────────────────────
static void _drawCellOverview() {
  const int16_t y0 = 238, aH = H - FTR_H - y0; // ~56px
  _tft.fillRect(0, y0, W, aH, C_BG);

  uint8_t n = bmsData.cellCount;
  if (!n || !bmsConnected) {
    _tft.setTextFont(1); _tft.setTextColor(C_DGRAY, C_BG);
    _tft.setTextDatum(MC_DATUM);
    _tft.drawString("BMS не підключено", W/2, y0+aH/2);
    return;
  }
  if (n > 24) n = 24;

  // Find min/max from animated values
  float mn = _A.cells[0].get(), mx = mn;
  for (uint8_t i=1;i<n;i++){
    float v=_A.cells[i].get();
    if(v<mn)mn=v; if(v>mx)mx=v;
  }
  float rng = mx-mn; if(rng<0.001f) rng=0.001f;

  // Info line
  char dbuf[30];
  snprintf(dbuf, sizeof(dbuf), "Δ %.0fmV  %.3f–%.3fV  %dS",
           rng*1000, mn, mx, n);
  _tft.setTextFont(1); _tft.setTextColor(C_GRAY, C_BG);
  _tft.setTextDatum(MC_DATUM);
  _tft.drawString(dbuf, W/2, y0+6);

  // Vertical bars with enter animation
  float enterMult = _A.enterStep / 20.0f;
  int16_t bW = (W-4)/n, bH = aH-16, bY0 = y0+13;

  for (uint8_t i=0;i<n;i++){
    float v   = _A.cells[i].get();
    bool  bal = (i<16)?((bmsData.balanceStatus  >>i)&1)
                       :((bmsData.balanceStatusHigh>>(i-16))&1);
    float pct = (v-mn)/rng * enterMult;
    uint16_t vc = (v==mx)?C_GREEN:(v==mn)?C_YELLOW:C_ACCENT;
    if(bal) vc=C_YELLOW;

    int16_t bx  = 2+i*bW;
    int16_t fh  = (int16_t)(bH * _clamp(pct,0,1));

    _tft.fillRect(bx, bY0, bW-1, bH, C_SUR2);
    if(fh>0) _tft.fillRect(bx, bY0+bH-fh, bW-1, fh, vc);

    // Glow cap
    if(fh>2)
      _tft.fillRect(bx, bY0+bH-fh, bW-1, 2, _blend(vc,C_WHITE,80));

    if(bal && _blink(400))
      _tft.fillRect(bx, bY0, bW-1, 2, C_YELLOW);
  }
}

static void _drawPage0() {
  _drawGauge();
  _drawMetrics();
  _drawTempFET();
  _drawCellOverview();
}

// ════════════════════════════════════════════════════════
//  PAGE 1 — CELL VOLTAGES (horizontal bars)
// ════════════════════════════════════════════════════════
static void _drawPage1() {
  _tft.fillRect(0, CTX_Y, W, CTX_H, C_BG);

  uint8_t n = bmsData.cellCount;
  if (!bmsConnected || !n) {
    _tft.setTextFont(2); _tft.setTextColor(C_GRAY, C_BG);
    _tft.setTextDatum(MC_DATUM);
    _tft.drawString("BMS не підключено", W/2, CTX_Y+CTX_H/2);
    return;
  }
  if (n > 24) n = 24;

  float mn = _A.cells[0].get(), mx = mn;
  for (uint8_t i=1;i<n;i++){
    float v=_A.cells[i].get();
    if(v<mn)mn=v; if(v>mx)mx=v;
  }
  float rng = mx-mn; if(rng<0.001f) rng=0.001f;

  // Header
  char hbuf[36];
  snprintf(hbuf,sizeof(hbuf),"min %.3f  max %.3f  Δ %.0f mV",mn,mx,rng*1000);
  _tft.setTextFont(1); _tft.setTextColor(C_GRAY, C_BG);
  _tft.setTextDatum(MC_DATUM);
  _tft.drawString(hbuf, W/2, CTX_Y+8);
  _tft.drawFastHLine(0, CTX_Y+17, W, C_BRD);

  // Rows
  const int16_t BAR_X = 38;          // label width
  const int16_t VAL_W = 34;          // value text width
  const int16_t BAR_W = W - BAR_X - VAL_W - 6;
  const float   RH    = (float)(CTX_H - 20) / n;
  const float   enterMult = _A.enterStep / 20.0f;

  for (uint8_t i=0;i<n;i++){
    float v   = _A.cells[i].get();
    bool  hi  = (v==mx), lo=(v==mn);
    bool  bal = (i<16)?((bmsData.balanceStatus  >>i)&1)
                       :((bmsData.balanceStatusHigh>>(i-16))&1);

    uint16_t vc = hi ? C_GREEN : lo ? C_YELLOW : C_ACCENT;
    if (bal) vc = C_YELLOW;

    int16_t y = CTX_Y + 19 + (int16_t)(i * RH);
    int16_t h = (int16_t)(RH) - 2;
    if (h < 4) h = 4;

    // Background row
    _tft.fillRect(0, y, W, h, (i%2==0) ? C_SUR : C_BG);

    // Cell label
    char lbl[5]; snprintf(lbl, sizeof(lbl), "C%d", i+1);
    _tft.setTextFont(1);
    _tft.setTextColor(hi||lo ? vc : C_GRAY, (i%2==0)?C_SUR:C_BG);
    _tft.setTextDatum(ML_DATUM);
    _tft.drawString(lbl, 2, y+h/2+1);

    // Bar
    float pct = ((v-mn)/rng) * enterMult;
    int16_t bw = (int16_t)(BAR_W * _clamp(pct,0,1));
    _tft.fillRect(BAR_X, y+1, BAR_W, h-2, C_BRD);
    if (bw > 0) {
      _tft.fillRect(BAR_X, y+1, bw, h-2, vc);
      // Glow cap
      if(bw > 3)
        _tft.fillRect(BAR_X+bw-3, y+1, 3, h-2, _blend(vc,C_WHITE,80));
    }

    // Balance blink
    if (bal && _blink(350))
      _tft.fillRect(BAR_X, y+1, BAR_W, h-2, C_BRD);

    // Value
    char vbuf[8]; snprintf(vbuf, sizeof(vbuf), "%.3f", v);
    _tft.setTextColor(vc, (i%2==0)?C_SUR:C_BG);
    _tft.setTextDatum(MR_DATUM);
    _tft.drawString(vbuf, W-2, y+h/2+1);

    // Hi/Lo marker
    if (hi || lo) {
      _tft.setTextColor(vc, (i%2==0)?C_SUR:C_BG);
      _tft.setTextDatum(ML_DATUM);
      _tft.drawString(hi?"▲":"▼", BAR_X+bw+2, y+h/2+1);
    }
  }
}

// ════════════════════════════════════════════════════════
//  PAGE 2 — SYSTEM STATUS
// ════════════════════════════════════════════════════════
static void _drawPage2() {
  _tft.fillRect(0, CTX_Y, W, CTX_H, C_BG);

  int16_t cy  = CTX_Y + 2;
  const int16_t RH = 19;
  char lb[28], rb[28];

  auto row = [&](const char* lbl, const char* val, uint16_t vc, uint16_t bg=C_BG) {
    _tft.fillRect(0, cy, W, RH, bg);
    _tft.setTextFont(1); _tft.setTextDatum(ML_DATUM);
    _tft.setTextColor(C_GRAY, bg);
    _tft.drawString(lbl, 6, cy+RH/2);
    _tft.setTextColor(vc, bg);
    _tft.setTextDatum(MR_DATUM);
    _tft.drawString(val, W-6, cy+RH/2);
    cy += RH;
    _tft.drawFastHLine(4, cy-1, W-8, C_BRD);
  };
  auto sect = [&](const char* t) {
    _tft.fillRect(0, cy, W, 15, C_SUR);
    _tft.setTextFont(1); _tft.setTextColor(C_ACCENT, C_SUR);
    _tft.setTextDatum(ML_DATUM);
    _tft.drawString(t, 6, cy+8);
    cy += 15;
  };

  sect(" WiFi");
  row("Статус", wifiConnected?"Connected":"AP only",
      wifiConnected?C_GREEN2:C_YELLOW);
  if (wifiConnected) {
    row("IP", WiFi.localIP().toString().c_str(), C_ACCENT);
    snprintf(lb, sizeof(lb), "%d dBm", WiFi.RSSI());
    row("RSSI", lb, WiFi.RSSI()>-65?C_GREEN2:C_YELLOW);
  }
  snprintf(lb, sizeof(lb), "%s", WiFi.softAPIP().toString().c_str());
  row("AP", lb, C_LGRAY);

  sect(" BMS");
  row("Статус", bmsConnected?"Connected":"Disconnected",
      bmsConnected?C_GREEN2:(_blink(600)?C_RED:C_DGRAY));
  if (bmsConnected) {
    String nm=BMS_NAME; if(nm.length()>18) nm=nm.substring(0,15)+"...";
    row("Device", nm.c_str(), C_WHITE);
    row("MAC", BMS_MAC.c_str(), C_GRAY);
    snprintf(lb, sizeof(lb), "v0x%02X  cyc:%d",
             bmsData.softwareVersion, bmsData.cycleCount);
    row("Info", lb, C_LGRAY);
  }

  sect(" Захист");
  uint16_t ps = bmsData.protectionStatus;
  uint16_t pcolor = ps==0?C_GREEN2:(_blink(250)?C_RED:C_BG);
  snprintf(lb, sizeof(lb), "0x%04X", ps);
  _tft.fillRect(0, cy, W, RH, ps?_blend(C_RED,C_BG,30):C_BG);
  row(ps==0?"OK  ✓":"FAULT!",lb, pcolor, ps?_blend(C_RED,C_BG,30):C_BG);
  if (ps && cy < H-FTR_H-RH) {
    static const char* fn[13]={"CellOVP","CellUVP","PackOVP","PackUVP",
      "ChgOTP","ChgUTP","DsgOTP","DsgUTP","ChgOCP","DsgOCP","SCP","AFE","Lock"};
    for(uint8_t i=0;i<13&&cy<H-FTR_H-RH;i++)
      if((ps>>i)&1){snprintf(lb,sizeof(lb),"  ▶ bit%d",i);row(lb,fn[i],C_RED);}
  }

  if (cy < H-FTR_H-RH*2) {
    sect(" Конфіг");
    row("Device ID", deviceId.c_str(), C_ACCENT);
    String srv=apiServer;
    if(srv.length()>22) srv=srv.substring(0,19)+"...";
    if(!srv.length()) srv="(не задано)";
    row("API", srv.c_str(), srv=="(не задано)"?C_DGRAY:C_GRAY);
  }
}

// ════════════════════════════════════════════════════════
//  PAGE WIPE TRANSITION
// ════════════════════════════════════════════════════════
static void _pageWipe() {
  // Швидкий горизонтальний wipe — 8 смуг по 30px
  for (int16_t y = CTX_Y; y < H-FTR_H; y += 30) {
    _tft.fillRect(0, y, W, 28, C_BG);
    delay(8); yield();
  }
}

// ════════════════════════════════════════════════════════
//  BOOT SPLASH
// ════════════════════════════════════════════════════════
static void _splash() {
  _tft.fillScreen(C_BG);

  // Outer ring animation
  for (uint8_t r = 80; r > 40; r -= 4) {
    _tft.drawCircle(W/2, H/2, r, _blend(C_ACCENT, C_BG, (80-r)*6));
    delay(20);
  }

  _tft.setTextDatum(MC_DATUM);
  _tft.setTextFont(4); _tft.setTextColor(C_ACCENT, C_BG);
  _tft.drawString("JBD BMS", W/2, H/2-44);

  _tft.setTextFont(2); _tft.setTextColor(C_GRAY, C_BG);
  _tft.drawString("Battery Controller", W/2, H/2-16);

  _tft.setTextFont(1); _tft.setTextColor(C_DGRAY, C_BG);
  _tft.drawString("ESP32-C3 Super Mini", W/2, H/2+4);
  _tft.drawString("GMT020-02  ST7789  240\xD7" "320", W/2, H/2+18);
  _tft.drawString("LovyanGFX", W/2, H/2+32);

  // Animated progress bar
  int16_t bx=40, by=H/2+55, bw=W-80;
  _tft.fillRoundRect(bx, by, bw, 8, 4, C_SUR2);
  _tft.drawRoundRect(bx, by, bw, 8, 4, C_BRD);
  for (uint8_t p=0; p<=100; p+=2) {
    int16_t fw = (bw-2)*p/100;
    uint16_t c = _blend(C_ACCENT, C_GREEN2, p*2);
    _tft.fillRoundRect(bx+1, by+1, fw, 6, 3, c);
    if (p%10==0) { delay(20); yield(); }
  }
  _tft.setTextFont(1); _tft.setTextColor(C_GREEN2, C_BG);
  _tft.drawString("Готово!", W/2, H/2+74);
  delay(400);
}

// ════════════════════════════════════════════════════════
//  PUBLIC API
// ════════════════════════════════════════════════════════

inline bool initDisplay() {
  Serial.println("[Display] init LovyanGFX ST7789");

  _tft.init();
  _tft.setRotation(0);
  _tft.fillScreen(C_BG);
  _tft.setBrightness(0);   // старт з вимкненим підсвіченням

  // Sprite для SOC gauge (240×130 = 60 KB)
  _spr.setColorDepth(16);
  if (!_spr.createSprite(W, 130)) {
    Serial.println("[Display] WARN: sprite alloc failed — direct draw");
  }

  displayDetected = true;
  displayActive   = true;

  // Плавне вмикання підсвітки
  for (uint8_t b = 0; b < _brt; b += 4) {
    _tft.setBrightness(b); delay(8);
  }
  _tft.setBrightness(_brt);

  _splash();
  _tft.fillScreen(C_BG);

  // Snap lerps до початкових значень (без анімації)
  _A.soc.snap(0); _A.volt.snap(0); _A.curr.snap(0); _A.pwr.snap(0);
  _A.arcAngle.snap(0);
  _A.enterStep = 0;
  _A.lastFrameMs = millis();
  _pgTimer = millis();
  _drawMs  = 0;
  _inited  = true;

  Serial.println("[Display] init OK");
  return true;
}

// Оновлення — викликати в loop() (10 fps)
inline void handleDisplay() {
  if (!_inited || !displayDetected || !displayActive) return;

  uint32_t now = millis();
  if (now - _drawMs < _DRAW_MS) return;
  _drawMs = now;

  // Авто-перемикання сторінок
  if (now - _pgTimer > _PG_MS) {
    _pageWipe();
    _pg = (_pg + 1) % _PG_CNT;
    _pgTimer = now;
    _A.enterStep = 0;
  }

  // Оновити цілі значень від bmsData
  _updateTargets();

  // Крок анімації
  _stepAnim();

  // Render
  _drawHdr(_pg==0?"JBD BMS  Dashboard":_pg==1?"Cell Voltages":"System Status");
  if      (_pg==0) _drawPage0();
  else if (_pg==1) _drawPage1();
  else             _drawPage2();
  _drawFtr();

  yield();
}

inline void nextDisplayPage() {
  _pageWipe();
  _pg = (_pg + 1) % _PG_CNT;
  _pgTimer = millis();
  _A.enterStep = 0;
}

inline void setDisplayBrightness(uint8_t brt) {
  _brt = brt;
  _tft.setBrightness(brt);
}

inline void setDisplayPower(bool on) {
  displayActive = on;
  if (on) {
    for (uint8_t b = 0; b <= _brt; b += 8) { _tft.setBrightness(b); delay(10); }
    _tft.setBrightness(_brt);
  } else {
    for (int b = _brt; b >= 0; b -= 8) { _tft.setBrightness((uint8_t)b); delay(6); }
    _tft.setBrightness(0);
    _tft.fillScreen(C_BG);
  }
}

inline void setPageInterval(uint32_t ms) { _PG_MS = ms; }
