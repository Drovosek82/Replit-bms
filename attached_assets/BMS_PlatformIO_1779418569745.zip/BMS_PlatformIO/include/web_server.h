// web_server.h — Web Server Module
// Зміни:
//   GET /scan       → запускає async BLE scan, повертає {"status":"scanning"} 202
//   GET /scan/status → {"scanning":bool, "devices":[{mac,name}]}
// ─────────────────────────────────────────────────────────
#pragma once
#include <Arduino.h>

#include <WebServer.h>
#include "GLOBAL_STATE.h"
#include "html_page.h"

inline WebServer server(80);

// ─── handleRoot ───────────────────────────────────────────
inline void handleRoot() {
  size_t htmlLen = strlen_P(HTML_PAGE);
  server.sendHeader("Content-Type",   "text/html; charset=utf-8");
  server.sendHeader("Content-Length", String(htmlLen));
  server.sendHeader("Cache-Control",  "no-cache");
  server.sendHeader("Connection",     "close");
  server.send(200, "text/html", "");

  const size_t CHUNK = 2048;
  char buf[CHUNK + 1];
  size_t pos = 0;
  while (pos < htmlLen) {
    size_t sz = min(htmlLen - pos, CHUNK);
    memcpy_P(buf, HTML_PAGE + pos, sz);
    buf[sz] = '\0';
    server.sendContent(buf);
    pos += sz;
    yield();
  }
  server.sendContent("");
}

// ─── handleData ──────────────────────────────────────────
inline void handleData() {
  server.sendHeader("Access-Control-Allow-Origin",  "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");

  StaticJsonDocument<2560> doc;

  doc["wifiConnected"]     = wifiConnected;
  doc["wifiInfo"]          = wifiConnected ? localIP.toString() : "";
  doc["bmsConnected"]      = bmsConnected;
  doc["bmsInfo"]           = bmsConnected ? BMS_NAME : "";
  doc["displayActive"]     = displayActive;
  doc["displayDetected"]   = displayDetected;

  doc["voltage"]           = bmsData.totalVoltage;
  doc["current"]           = bmsData.current;
  doc["soc"]               = bmsData.soc;
  doc["capacity"]          = bmsData.capacityRemaining;
  doc["totalCapacity"]     = bmsData.capacityTotal;
  doc["cellCount"]         = bmsData.cellCount;
  doc["fetStatus"]         = bmsData.fetStatus;
  doc["cycleCount"]        = bmsData.cycleCount;
  doc["tempSensorCount"]   = bmsData.tempSensorCount;
  doc["balanceStatus"]     = bmsData.balanceStatus;
  doc["balanceStatusHigh"] = bmsData.balanceStatusHigh;
  doc["protectionStatus"]  = bmsData.protectionStatus;
  doc["softwareVersion"]   = bmsData.softwareVersion;
  doc["productionDate"]    = bmsData.productionDate;

  if (bmsConnected && bmsData.tempSensorCount > 0) {
    JsonArray temps = doc.createNestedArray("temperatures");
    for (uint8_t i = 0; i < bmsData.tempSensorCount && i < 6; i++) {
      temps.add(bmsData.temperatures[i]); yield();
    }
  }
  if (bmsConnected && bmsData.cellCount > 0) {
    JsonArray cells = doc.createNestedArray("cellVoltages");
    for (uint8_t i = 0; i < bmsData.cellCount && i < 24; i++) {
      cells.add(bmsData.cellVoltages[i]); yield();
    }
  }

  String response;
  serializeJson(doc, response);
  server.send(200, "application/json", response);
}

// ─── handleControl ────────────────────────────────────────
inline void handleControl() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  String cmd = server.arg("cmd");

  if (cmd == "mos") {
    int state = server.arg("state").toInt();
    if (state >= 0 && state <= 3) {
      controlMOSFET((uint8_t)state);
      server.send(200, "application/json",
        "{\"status\":\"ok\",\"state\":" + String(state) + "}");
    } else {
      server.send(400, "application/json",
        "{\"status\":\"error\",\"message\":\"state 0-3\"}");
    }
  } else {
    server.send(400, "application/json",
      "{\"status\":\"error\",\"message\":\"unknown cmd\"}");
  }
}

// ─── handleScan — запускає async BLE scan ─────────────────
// Повертає 202 якщо scan запущено, 200 якщо вже сканує
inline void handleScan() {
  server.sendHeader("Access-Control-Allow-Origin", "*");

  if (!isBLEScanning()) {
    startBLEScan();   // non-blocking — запускає FreeRTOS task
    Serial.println("[Web] /scan → async scan started");
    server.send(202, "application/json",
      "{\"status\":\"scanning\",\"scanning\":true}");
  } else {
    // Вже сканує — просто повідомити
    server.send(200, "application/json",
      "{\"status\":\"scanning\",\"scanning\":true}");
  }
}

// ─── handleScanStatus — стан та результати scan ───────────
// Клієнт поллінгує кожну секунду до scanning=false
inline void handleScanStatus() {
  server.sendHeader("Access-Control-Allow-Origin", "*");

  bool running = isBLEScanning();

  StaticJsonDocument<1024> doc;
  doc["scanning"] = running;

  if (!running) {
    // Scan завершено — повернути результати
    JsonArray devices = doc.createNestedArray("devices");
    for (int i = 0; i < bmsCount; i++) {
      int pipe = availableBMS[i].indexOf('|');
      JsonObject d = devices.createNestedObject();
      d["mac"]  = availableBMS[i].substring(0, pipe);
      d["name"] = availableBMS[i].substring(pipe + 1);
      yield();
    }
    Serial.printf("[Web] /scan/status: done, %d devices\n", bmsCount);
  }

  String response;
  serializeJson(doc, response);
  server.send(200, "application/json", response);
}

// ─── handleWiFiScan ───────────────────────────────────────
inline void handleWiFiScan() {
  server.sendHeader("Access-Control-Allow-Origin", "*");

  String networks[20];
  int count = 0;
  scanWiFiNetworks(networks, count, 20);

  StaticJsonDocument<1024> doc;
  JsonArray arr = doc.createNestedArray("networks");
  for (int i = 0; i < count; i++) {
    int p1 = networks[i].indexOf('|');
    int p2 = networks[i].indexOf('|', p1 + 1);
    JsonObject n = arr.createNestedObject();
    n["ssid"] = networks[i].substring(0, p1);
    n["rssi"] = networks[i].substring(p1 + 1, p2).toInt();
    n["open"] = (networks[i].substring(p2 + 1) == "0");
    yield();
  }

  String response;
  serializeJson(doc, response);
  server.send(200, "application/json", response);
}

// ─── handleConnect ────────────────────────────────────────
inline void handleConnect() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  StaticJsonDocument<200> doc;
  deserializeJson(doc, server.arg("plain"));

  String mac  = doc["mac"]  | "";
  String name = doc["name"] | "";

  if (mac.length() == 0) {
    server.send(400, "application/json",
      "{\"status\":\"error\",\"message\":\"mac required\"}");
    return;
  }
  Serial.printf("[Web] POST /connect mac=%s\n", mac.c_str());

  if (connectToBMS(mac, name))
    server.send(200, "application/json", "{\"status\":\"connected\"}");
  else
    server.send(400, "application/json", "{\"status\":\"failed\"}");
}

// ─── handleDisconnect ─────────────────────────────────────
inline void handleDisconnect() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  disconnectBMS();
  server.send(200, "application/json", "{\"status\":\"disconnected\"}");
}

// ─── handleDisplay ────────────────────────────────────────
inline void handleDisplayCmd() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  String cmd = server.arg("cmd");

  if (!displayDetected) {
    server.send(200, "application/json",
      "{\"status\":\"ok\",\"displayActive\":false,\"displayDetected\":false}");
    return;
  }

  if      (cmd == "toggle") setDisplayPower(!displayActive);
  else if (cmd == "on")     setDisplayPower(true);
  else if (cmd == "off")    setDisplayPower(false);
  else {
    server.send(400, "application/json",
      "{\"status\":\"error\",\"message\":\"cmd: toggle|on|off\"}");
    return;
  }

  String r = "{\"status\":\"ok\",\"displayActive\":" +
             String(displayActive ? "true" : "false") + "}";
  server.send(200, "application/json", r);
}

// ─── handleSave ──────────────────────────────────────────
inline void handleSave() {
  String ssid     = server.arg("ssid");
  String password = server.arg("password");
  String apiSrv   = server.arg("apiServer");
  String devId    = server.arg("deviceId");

  if (ssid.length() == 0) {
    server.send(400, "text/plain", "Error: ssid required");
    return;
  }
  bool ok1 = saveWiFiConfig(ssid, password);
  bool ok2 = true;
  if (apiSrv.length() > 0 || devId.length() > 0) {
    ok2 = saveAppConfig(
      apiSrv.length() > 0 ? apiSrv : apiServer,
      devId.length()  > 0 ? devId  : deviceId
    );
  }

  if (ok1 && ok2) {
    server.send(200, "text/plain", "Saved. Restarting...");
    shouldRestart = true;
  } else {
    server.send(500, "text/plain", "Error saving");
  }
}

// ─── CORS preflight ───────────────────────────────────────
inline void handleOptions() {
  server.sendHeader("Access-Control-Allow-Origin",  "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
  server.send(204);
}

inline void handleNotFound() {
  if (server.method() == HTTP_OPTIONS) { handleOptions(); return; }
  server.send(404, "text/plain",
    "404\nEndpoints: / /data /control /scan /scan/status /wifiscan /connect /disconnect /save /display");
}

// ─── initWebServer ────────────────────────────────────────
inline void initWebServer() {
  server.on("/",            HTTP_GET,  handleRoot);
  server.on("/data",        HTTP_GET,  handleData);
  server.on("/control",     HTTP_GET,  handleControl);
  server.on("/scan",        HTTP_GET,  handleScan);         // async start
  server.on("/scan/status", HTTP_GET,  handleScanStatus);   // NEW: poll results
  server.on("/wifiscan",    HTTP_GET,  handleWiFiScan);
  server.on("/connect",     HTTP_POST, handleConnect);
  server.on("/disconnect",  HTTP_GET,  handleDisconnect);
  server.on("/save",        handleSave);
  server.on("/display", HTTP_GET, handleDisplayCmd);
  server.onNotFound(handleNotFound);

  server.begin();
  Serial.printf("[Web] Started — AP: http://%s  STA: http://%s\n",
    WiFi.softAPIP().toString().c_str(),
    wifiConnected ? localIP.toString().c_str() : "n/a");
}
