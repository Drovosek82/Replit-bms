// api_client.h — BMS Data Push to External Server (Replit / etc.)
// ESP32-C3 Super Mini + JBD BMS
//
// Зміни відносно оригіналу:
//  - DynamicJsonDocument збільшено до 1024 (для cellVoltages)
//  - Додано: capacity, totalCapacity, balanceStatus, balanceStatusHigh
//            protectionStatus, softwareVersion, productionDate
//            cellVoltages[], rssi, wifiIp, uptime
// ─────────────────────────────────────────────────────────────
#pragma once
#include <Arduino.h>

#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>
#include <WiFi.h>
#include "GLOBAL_STATE.h"

// ─── Timing ───────────────────────────────────────────────
// Змінити API_UPDATE_INTERVAL через веб-інтерфейс → /save
// або відредагувати нижче і перепрошити
inline unsigned long API_UPDATE_INTERVAL = 5000;  // 5 секунд
inline unsigned long lastAPISend         = 0;

// ─── Build JSON payload ───────────────────────────────────
// Формує повний JSON з усіх доступних полів bmsData.
// Payload відповідає точно тому що очікує Replit-застосунок.
inline String buildPayload() {
  DynamicJsonDocument doc(1536);  // ~1.5KB для JSON з cellVoltages[24]

  // ── Завжди присутні ───────────────────────────────────
  doc["device_id"]  = deviceId;
  doc["timestamp"]  = millis();          // мс з моменту старту
  doc["voltage"]    = bmsData.totalVoltage;
  doc["current"]    = bmsData.current;
  doc["soc"]        = bmsData.soc;       // uint8_t %

  // ── Якщо BMS підключено ───────────────────────────────
  if (bmsConnected) {
    // Ємність
    doc["capacity"]           = bmsData.capacityRemaining;
    doc["total_capacity"]     = bmsData.capacityTotal;

    // Метадані
    doc["cell_count"]         = bmsData.cellCount;
    doc["cycle_count"]        = bmsData.cycleCount;
    doc["fet_status"]         = bmsData.fetStatus;     // bit0=CHG, bit1=DSG
    doc["software_version"]   = bmsData.softwareVersion;
    doc["production_date"]    = bmsData.productionDate;

    // Захист та баланс (uint16 bitmask)
    doc["protection_status"]  = bmsData.protectionStatus;
    doc["balance_status"]     = bmsData.balanceStatus;
    doc["balance_status_high"]= bmsData.balanceStatusHigh;

    // Температури
    if (bmsData.tempSensorCount > 0) {
      JsonArray temps = doc.createNestedArray("temperatures");
      for (uint8_t i = 0; i < bmsData.tempSensorCount && i < 6; i++) {
        temps.add(bmsData.temperatures[i]);
        yield();
      }
    }

    // Напруги клітин
    if (bmsData.cellCount > 0) {
      JsonArray cells = doc.createNestedArray("cell_voltages");
      for (uint8_t i = 0; i < bmsData.cellCount && i < 24; i++) {
        cells.add(bmsData.cellVoltages[i]);
        yield();
      }

      // Дельта напруг (max-min, мВ) — корисна метрика
      float mn = bmsData.cellVoltages[0], mx = mn;
      for (uint8_t i=1; i<bmsData.cellCount && i<24; i++) {
        if (bmsData.cellVoltages[i] < mn) mn = bmsData.cellVoltages[i];
        if (bmsData.cellVoltages[i] > mx) mx = bmsData.cellVoltages[i];
      }
      doc["cell_delta_mv"] = (int)((mx - mn) * 1000 + 0.5f);
    }
  }

  // ── WiFi метрики ──────────────────────────────────────
  if (wifiConnected) {
    doc["rssi"]     = WiFi.RSSI();
    doc["wifi_ip"]  = localIP.toString();
  }

  String out;
  serializeJson(doc, out);
  return out;
}

// ─── pushBMSData ─────────────────────────────────────────
inline void pushBMSData() {
  if (!wifiConnected) {
    Serial.println("[API] WiFi не підключено, пропуск");
    return;
  }
  if (apiServer.length() == 0) {
    Serial.println("[API] apiServer не задано, пропуск");
    return;
  }

  String payload = buildPayload();
  Serial.printf("[API] POST → %s (%u bytes)\n",
                apiServer.c_str(), (unsigned)payload.length());

  WiFiClientSecure client;
  client.setInsecure();  // без перевірки сертифіката (Replit / self-signed)
  client.setTimeout(10);

  HTTPClient http;
  http.setTimeout(10000);

  if (!http.begin(client, apiServer)) {
    Serial.println("[API] Помилка ініціалізації HTTP");
    return;
  }

  http.addHeader("Content-Type", "application/json");
  http.addHeader("User-Agent",   "ESP32-BMS-Controller/1.0");
  http.addHeader("X-Device-ID",  deviceId);

  int code = http.POST(payload);

  if (code > 0) {
    Serial.printf("[API] Відповідь: %d\n", code);
    if (code != HTTP_CODE_OK) {
      String resp = http.getString();
      Serial.printf("[API] Body: %s\n", resp.c_str());
    }
  } else {
    Serial.printf("[API] Помилка: %s\n", http.errorToString(code).c_str());
  }

  http.end();
  yield();
}

// ─── handleAPIData — викликати у loop() ──────────────────
inline void handleAPIData() {
  if (millis() - lastAPISend < API_UPDATE_INTERVAL) return;
  lastAPISend = millis();

  if (!bmsConnected) {
    Serial.println("[API] BMS не підключено, пропуск відправки");
    return;
  }

  pushBMSData();
}

// ─── testAPIServer — тест підключення ─────────────────────
inline bool testAPIServer() {
  if (apiServer.length() == 0) {
    Serial.println("[API] apiServer не задано");
    return false;
  }

  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setTimeout(5000);

  if (!http.begin(client, apiServer)) return false;

  int code = http.GET();
  http.end();

  Serial.printf("[API] Test GET → %d\n", code);
  return (code > 0);
}
