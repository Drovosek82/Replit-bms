// bms.h — BLE + JBD BMS протокол
// ASYNC SCAN: startBLEScan() запускає FreeRTOS task → не блокує HTTP
// ESP32-C3: один радіо. BLE ініціалізується ПІСЛЯ WiFi AP.
// ─────────────────────────────────────────────────────────
#pragma once

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEClient.h>
#include <BLEScan.h>
#include <BLEAdvertisedDevice.h>
#include <BLERemoteCharacteristic.h>
#include <Preferences.h>
#include "GLOBAL_STATE.h"

// ─── Async scan state ────────────────────────────────────
static volatile bool _scanRunning = false;  // true поки task живий
static volatile bool _scanDone    = false;  // true після завершення

inline bool isBLEScanning() { return _scanRunning; }

// ─── BLE notification callback ───────────────────────────
static void _bmsNotifyCB(BLERemoteCharacteristic*,
                          uint8_t* data, size_t len, bool) {
  static uint8_t  buf[512];
  static size_t   bufLen = 0;
  static uint32_t lastMs = 0;

  if (millis() - lastMs > 150) bufLen = 0;
  lastMs = millis();

  if (bufLen + len <= sizeof(buf)) {
    memcpy(buf + bufLen, data, len);
    bufLen += len;
  }
  if (bufLen > 0 && buf[bufLen - 1] == 0x77) {
    memcpy(bmsResponse, buf, bufLen);
    bmsResponseLength = bufLen;
    newDataReceived   = true;
    bufLen = 0;
  }
}

// ─── BLE client callbacks ─────────────────────────────────
class _BmsCB : public BLEClientCallbacks {
  void onConnect(BLEClient*)    override {}
  void onDisconnect(BLEClient*) override {
    bmsConnected = false;
    Serial.println("[BMS] BLE disconnected");
  }
};

// ─── BLE scan callback ────────────────────────────────────
class _ScanCB : public BLEAdvertisedDeviceCallbacks {
  void onResult(BLEAdvertisedDevice dev) override {
    if (bmsCount >= 20) return;
    String addr = dev.getAddress().toString().c_str();
    String name = dev.haveName()
      ? String(dev.getName().c_str())
      : ("Unknown_" + addr.substring(12));
    // Перевірити дублікати по MAC
    for (int i = 0; i < bmsCount; i++) {
      if (availableBMS[i].startsWith(addr)) return;
    }
    availableBMS[bmsCount++] = addr + "|" + name;
  }
};

// ─── JBD CRC ─────────────────────────────────────────────
static uint16_t _jbdCRC(const uint8_t* d, size_t n) {
  uint16_t s = 0;
  for (size_t i = 0; i < n; i++) s += d[i];
  return ((~s) + 1) & 0xFFFF;
}

static bool _verifyCRC(const uint8_t* d, size_t n) {
  if (n < 6 || d[n-1] != 0x77) return false;
  uint16_t calc = _jbdCRC(d, n - 3);
  uint16_t recv = ((uint16_t)d[n-3] << 8) | d[n-2];
  if (calc == recv) return true;
  if (n > 4 && (d[1] == 0x03 || d[1] == 0x04)) {
    Serial.printf("[BMS] CRC warn cmd=0x%02X calc=%04X got=%04X — ok\n",
                  d[1], calc, recv);
    return true;
  }
  return false;
}

// ─── Відправити команду ───────────────────────────────────
static bool _sendCmd(const uint8_t* cmd, size_t len, uint32_t ms = 2000) {
  if (!pClient || !pClient->isConnected() || !pRxCharacteristic) {
    Serial.println("[BMS] Not connected");
    return false;
  }
  newDataReceived   = false;
  bmsResponseLength = 0;
  pRxCharacteristic->writeValue(const_cast<uint8_t*>(cmd), len, false);

  uint32_t t0 = millis();
  while (!newDataReceived && millis() - t0 < ms) {
    delay(2); yield();
  }
  if (!newDataReceived) { Serial.println("[BMS] Timeout"); return false; }
  delay(30); yield();
  return _verifyCRC(bmsResponse, bmsResponseLength);
}

// ─── Read Basic Info (0x03) ──────────────────────────────
static bool _readBasicInfo() {
  static const uint8_t cmd[] = {0xDD, 0xA5, 0x03, 0x00, 0xFF, 0xFD, 0x77};
  if (!_sendCmd(cmd, sizeof(cmd))) return false;
  if (bmsResponseLength < 0x1D)   return false;

  const uint8_t* r = bmsResponse;
  bmsData.totalVoltage      = ((r[4]  << 8) | r[5])  / 100.0f;
  bmsData.current           = (int16_t)((r[6] << 8) | r[7]) / 100.0f;
  bmsData.capacityRemaining = ((r[8]  << 8) | r[9])  / 100.0f;
  bmsData.capacityTotal     = ((r[10] << 8) | r[11]) / 100.0f;
  bmsData.cycleCount        = (r[12] << 8) | r[13];
  bmsData.productionDate    = String("20") + String(r[14]) + "/" +
                              String(r[15]) + "/" + String(r[16]);
  bmsData.balanceStatus     = (r[17] << 8) | r[18];
  bmsData.balanceStatusHigh = (r[19] << 8) | r[20];
  bmsData.protectionStatus  = (r[21] << 8) | r[22];
  bmsData.softwareVersion   = r[23];
  bmsData.fetStatus         = r[24];
  bmsData.cellCount         = r[25];
  bmsData.tempSensorCount   = r[26];

  for (uint8_t i = 0; i < bmsData.tempSensorCount && i < 6; i++) {
    uint16_t raw = (r[27 + i*2] << 8) | r[27 + i*2 + 1];
    bmsData.temperatures[i] = (raw - 2731) / 10.0f;
    yield();
  }
  for (uint8_t i = bmsData.tempSensorCount; i < 6; i++)
    bmsData.temperatures[i] = 0.0f;

  bmsData.soc = (bmsData.capacityTotal > 0)
    ? (uint8_t)((bmsData.capacityRemaining / bmsData.capacityTotal) * 100.0f + 0.5f)
    : 0;

  Serial.printf("[BMS] V=%.2f A=%.2f SOC=%d%% T0=%.1f cells=%d prot=0x%04X\n",
    bmsData.totalVoltage, bmsData.current, bmsData.soc,
    bmsData.temperatures[0], bmsData.cellCount, bmsData.protectionStatus);
  yield();
  return true;
}

// ─── Read Cell Voltages (0x04) ───────────────────────────
static bool _readCellVoltages() {
  static const uint8_t cmd[] = {0xDD, 0xA5, 0x04, 0x00, 0xFF, 0xFC, 0x77};
  if (!_sendCmd(cmd, sizeof(cmd))) return false;

  size_t expected = 4 + (size_t)(bmsData.cellCount * 2) + 3;
  if (bmsResponseLength < expected) {
    Serial.printf("[BMS] Cell resp too short: %u < %u\n",
                  (unsigned)bmsResponseLength, (unsigned)expected);
    return false;
  }
  for (uint8_t i = 0; i < bmsData.cellCount && i < 24; i++) {
    uint16_t raw = (bmsResponse[4 + i*2] << 8) | bmsResponse[4 + i*2 + 1];
    bmsData.cellVoltages[i] = raw / 1000.0f;
    yield();
  }
  Serial.printf("[BMS] %d cells read\n", bmsData.cellCount);
  yield();
  return true;
}

// ════════════════════════════════════════════════════════
//  ASYNC SCAN  (FreeRTOS Task — не блокує HTTP/WiFi)
// ════════════════════════════════════════════════════════
static void _bleScanTask(void* param) {
  Serial.println("[BMS] scan task start");
  bmsCount = 0;

  BLEScan* scan = BLEDevice::getScan();
  scan->setAdvertisedDeviceCallbacks(new _ScanCB(), true);
  scan->setActiveScan(true);
  scan->setInterval(100);    // 100 ms
  scan->setWindow(99);       // 99 ms active window
  scan->start(3, false);     // 3 с — менше конфлікту з WiFi
  scan->stop();
  scan->clearResults();

  _scanRunning = false;
  _scanDone    = true;
  Serial.printf("[BMS] scan task done: %d devices\n", bmsCount);
  vTaskDelete(nullptr);      // видалити сам себе
}

// Запустити асинхронне сканування (повертається миттєво)
inline void startBLEScan() {
  if (_scanRunning) {
    Serial.println("[BMS] scan already running");
    return;
  }
  _scanRunning = true;
  _scanDone    = false;
  // Stack 8 KB — BLE операції потребують місця
  BaseType_t res = xTaskCreate(_bleScanTask, "ble_scan",
                                12288, nullptr, 1, nullptr);
  if (res != pdPASS) {
    Serial.println("[BMS] scan task create failed");
    _scanRunning = false;
  } else {
    Serial.println("[BMS] async scan started");
  }
}

// ════════════════════════════════════════════════════════
//  PUBLIC API
// ════════════════════════════════════════════════════════

inline void initBMS() {
  memset(&bmsData, 0, sizeof(bmsData));
  BLEDevice::init("ESP32-BMS");

  if (!pClient) {
    pClient = BLEDevice::createClient();
    pClient->setClientCallbacks(new _BmsCB());
  }

  Preferences prefs;
  prefs.begin("bms-cfg", true);
  BMS_MAC  = prefs.getString("mac",  "");
  BMS_NAME = prefs.getString("name", "");
  prefs.end();

  if (BMS_MAC.length())
    Serial.printf("[BMS] Saved: %s (%s)\n", BMS_MAC.c_str(), BMS_NAME.c_str());

  Serial.println("[BMS] initBMS() OK — coexistence active");
}

inline bool connectToBMS(const String& mac, const String& name) {
  if (mac.length() == 0) return false;
  Serial.printf("[BMS] Connecting: %s (%s)\n", name.c_str(), mac.c_str());

  if (!pClient) {
    pClient = BLEDevice::createClient();
    pClient->setClientCallbacks(new _BmsCB());
  }
  if (pClient->isConnected()) pClient->disconnect();

  if (!pClient->connect(BLEAddress(mac.c_str()))) {
    Serial.println("[BMS] Connect failed");
    return false;
  }

  BLERemoteService* svc = pClient->getService(SERVICE_UUID);
  if (!svc) {
    Serial.println("[BMS] Service not found");
    pClient->disconnect(); return false;
  }

  pTxCharacteristic = svc->getCharacteristic(CHAR_TX_UUID);
  pRxCharacteristic = svc->getCharacteristic(CHAR_RX_UUID);

  if (!pTxCharacteristic || !pRxCharacteristic) {
    Serial.println("[BMS] Characteristics not found");
    pClient->disconnect(); return false;
  }

  if (pTxCharacteristic->canNotify())
    pTxCharacteristic->registerForNotify(_bmsNotifyCB);

  bmsConnected = true;
  BMS_MAC  = mac;
  BMS_NAME = name;

  Preferences prefs;
  prefs.begin("bms-cfg", false);
  prefs.putString("mac",  mac);
  prefs.putString("name", name);
  prefs.end();

  Serial.println("[BMS] Connected OK");
  return true;
}

inline void disconnectBMS() {
  if (pClient && pClient->isConnected()) pClient->disconnect();
  bmsConnected = false;
  Serial.println("[BMS] Disconnected");
}

inline bool updateBMSData() {
  if (!bmsConnected) return false;
  if (!_readBasicInfo())    return false;
  delay(80); yield();
  if (!_readCellVoltages()) return false;
  return true;
}

// state: 0=all off, 1=CHG only, 2=DSG only, 3=both on
inline void controlMOSFET(uint8_t state) {
  uint8_t wcmd[8] = {0xDD, 0x5A, 0x94, 0x01, state, 0x00, 0x00, 0x77};
  uint16_t crc = _jbdCRC(wcmd + 2, 3);
  wcmd[5] = (crc >> 8) & 0xFF;
  wcmd[6] = crc & 0xFF;
  _sendCmd(wcmd, sizeof(wcmd), 1000);
  Serial.printf("[BMS] MOSFET state=%d\n", state);
}
