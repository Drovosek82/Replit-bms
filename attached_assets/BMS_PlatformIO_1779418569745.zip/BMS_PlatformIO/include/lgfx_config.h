// lgfx_config.h — LovyanGFX конфігурація дисплею
// Board:   ESP32-C3 Super Mini
// Display: GMT020-02 (ST7789V, 240×320, SPI 4-line)
//
// ПРАВИЛЬНА СХЕМА ПІДКЛЮЧЕННЯ:
//  GMT020-02      ESP32-C3 GPIO
//  Pin17 RS/SCL → GPIO 4  ← FSPI_CLK
//  Pin21 SDA    → GPIO 6  ← FSPI_MOSI
//  Pin16 WR/DC  → GPIO 2  ← Data/Command
//  Pin18 CS     → GPIO 7  ← Chip Select
//  Pin20 RESET  → GPIO 3  ← Reset
//  Pin1  LED+   → GPIO 11 ← Backlight PWM (через 33Ω до GND)
//  Pin2  LED-   → GND
//  Pin6  VCC    → 3V3
//  Pin22 GND    → GND
//  Pin3  IM2    → 3V3  (SPI режим: IM2=H, IM1=H, IM0=L)
//  Pin4  IM1    → 3V3
//  Pin5  IM0    → GND
// ─────────────────────────────────────────────────────────
#pragma once
#include <LovyanGFX.hpp>

class LGFX : public lgfx::LGFX_Device {
  lgfx::Panel_ST7789 _panel;
  lgfx::Bus_SPI      _bus;
  lgfx::Light_PWM    _light;

public:
  LGFX() {
    // ── SPI Bus ─────────────────────────────────────────
    {
      auto cfg = _bus.config();
      cfg.spi_host    = SPI2_HOST;       // FSPI (єдиний апаратний SPI на C3)
      cfg.spi_mode    = 0;
      cfg.freq_write  = 40000000;        // 40 MHz (GMT020-02 max ~62 MHz)
      cfg.freq_read   = 16000000;
      cfg.spi_3wire   = false;
      cfg.use_lock    = true;
      cfg.dma_channel = SPI_DMA_CH_AUTO;
      // ПРАВИЛЬНІ GPIO (значення = номер GPIO, НЕ пін дисплею!)
      cfg.pin_sclk =  2;   // GPIO 2  → Display Pin17 RS/SCL
      cfg.pin_mosi =  4;   // GPIO 4  → Display Pin21 SDA
      cfg.pin_miso = -1;
      cfg.pin_dc   =  6;   // GPIO 6  → Display Pin16 WR/DC
      _bus.config(cfg);
      _panel.setBus(&_bus);
    }

    // ── Panel ST7789V ────────────────────────────────────
    {
      auto cfg = _panel.config();
      cfg.pin_cs   =  5;   // GPIO 5  → Display Pin18 CS
      cfg.pin_rst  =  7;   // GPIO 7  → Display Pin20 RESET
      cfg.pin_busy = -1;
      cfg.memory_width  = 240;
      cfg.memory_height = 320;
      cfg.panel_width   = 240;
      cfg.panel_height  = 320;
      cfg.offset_x = 0;
      cfg.offset_y = 0;
      cfg.offset_rotation = 0;
      cfg.dummy_read_pixel = 8;
      cfg.dummy_read_bits  = 1;
      cfg.readable   = false;
      cfg.invert     = false; // якщо кольори інвертовані — змінити на true
      cfg.rgb_order  = false; // ST7789 = BGR
      cfg.dlen_16bit = false;
      cfg.bus_shared = false;
      _panel.config(cfg);
    }

    // ── Backlight PWM ────────────────────────────────────
    {
      auto cfg = _light.config();
      cfg.pin_bl      = 11;    // GPIO 11 → Display Pin1 LED+
      cfg.invert      = false;
      cfg.freq        = 12000; // 12 kHz (вище порогу слуху)
      cfg.pwm_channel = 7;
      _light.config(cfg);
      _panel.setLight(&_light);
    }

    setPanel(&_panel);
  }
};
